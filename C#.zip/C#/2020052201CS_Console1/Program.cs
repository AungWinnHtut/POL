﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2020052201CS_Console1
{
    class Program
    {
        static void Main(string[] args)
        {
            int iSize = sizeof(double);
            Console.WriteLine("Size of int : {0}", iSize);
            Console.ReadKey();
        }
    }
}
