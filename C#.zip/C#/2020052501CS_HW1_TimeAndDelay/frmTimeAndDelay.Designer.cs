﻿namespace _2020052501CS_HW1_TimeAndDelay
{
    partial class frmTimeAndDelay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTimeAndDelay));
            this.picUI = new System.Windows.Forms.PictureBox();
            this.txtSH = new System.Windows.Forms.TextBox();
            this.txtSM = new System.Windows.Forms.TextBox();
            this.txtEH = new System.Windows.Forms.TextBox();
            this.txtEM = new System.Windows.Forms.TextBox();
            this.txtDH = new System.Windows.Forms.TextBox();
            this.txtDM = new System.Windows.Forms.TextBox();
            this.txtQ1 = new System.Windows.Forms.TextBox();
            this.txtQ2 = new System.Windows.Forms.TextBox();
            this.txtQ3 = new System.Windows.Forms.TextBox();
            this.rdoAM = new System.Windows.Forms.RadioButton();
            this.rdoPM = new System.Windows.Forms.RadioButton();
            this.btnSubmit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picUI)).BeginInit();
            this.SuspendLayout();
            // 
            // picUI
            // 
            this.picUI.Image = ((System.Drawing.Image)(resources.GetObject("picUI.Image")));
            this.picUI.Location = new System.Drawing.Point(-4, 92);
            this.picUI.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.picUI.Name = "picUI";
            this.picUI.Size = new System.Drawing.Size(758, 412);
            this.picUI.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picUI.TabIndex = 0;
            this.picUI.TabStop = false;
            this.picUI.Click += new System.EventHandler(this.picUI_Click);
            // 
            // txtSH
            // 
            this.txtSH.Enabled = false;
            this.txtSH.Location = new System.Drawing.Point(45, 218);
            this.txtSH.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtSH.Name = "txtSH";
            this.txtSH.Size = new System.Drawing.Size(53, 26);
            this.txtSH.TabIndex = 1;
            // 
            // txtSM
            // 
            this.txtSM.Enabled = false;
            this.txtSM.Location = new System.Drawing.Point(126, 218);
            this.txtSM.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtSM.Name = "txtSM";
            this.txtSM.Size = new System.Drawing.Size(54, 26);
            this.txtSM.TabIndex = 2;
            // 
            // txtEH
            // 
            this.txtEH.Location = new System.Drawing.Point(547, 217);
            this.txtEH.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtEH.Name = "txtEH";
            this.txtEH.Size = new System.Drawing.Size(58, 26);
            this.txtEH.TabIndex = 3;
            // 
            // txtEM
            // 
            this.txtEM.Location = new System.Drawing.Point(628, 219);
            this.txtEM.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtEM.Name = "txtEM";
            this.txtEM.Size = new System.Drawing.Size(58, 26);
            this.txtEM.TabIndex = 4;
            // 
            // txtDH
            // 
            this.txtDH.Enabled = false;
            this.txtDH.Location = new System.Drawing.Point(270, 369);
            this.txtDH.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtDH.Name = "txtDH";
            this.txtDH.Size = new System.Drawing.Size(60, 26);
            this.txtDH.TabIndex = 5;
            // 
            // txtDM
            // 
            this.txtDM.Enabled = false;
            this.txtDM.Location = new System.Drawing.Point(351, 368);
            this.txtDM.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtDM.Name = "txtDM";
            this.txtDM.Size = new System.Drawing.Size(56, 26);
            this.txtDM.TabIndex = 6;
            // 
            // txtQ1
            // 
            this.txtQ1.BackColor = System.Drawing.SystemColors.Control;
            this.txtQ1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ1.Font = new System.Drawing.Font("Zawgyi-One", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ1.Location = new System.Drawing.Point(28, 29);
            this.txtQ1.Name = "txtQ1";
            this.txtQ1.Size = new System.Drawing.Size(703, 38);
            this.txtQ1.TabIndex = 7;
            // 
            // txtQ2
            // 
            this.txtQ2.BackColor = System.Drawing.SystemColors.Control;
            this.txtQ2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ2.Font = new System.Drawing.Font("Zawgyi-One", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ2.Location = new System.Drawing.Point(28, 81);
            this.txtQ2.Name = "txtQ2";
            this.txtQ2.Size = new System.Drawing.Size(703, 38);
            this.txtQ2.TabIndex = 8;
            // 
            // txtQ3
            // 
            this.txtQ3.BackColor = System.Drawing.SystemColors.Control;
            this.txtQ3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ3.Font = new System.Drawing.Font("Zawgyi-One", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ3.Location = new System.Drawing.Point(28, 133);
            this.txtQ3.Name = "txtQ3";
            this.txtQ3.Size = new System.Drawing.Size(703, 38);
            this.txtQ3.TabIndex = 9;
            // 
            // rdoAM
            // 
            this.rdoAM.AutoSize = true;
            this.rdoAM.Checked = true;
            this.rdoAM.Location = new System.Drawing.Point(628, 261);
            this.rdoAM.Name = "rdoAM";
            this.rdoAM.Size = new System.Drawing.Size(58, 24);
            this.rdoAM.TabIndex = 10;
            this.rdoAM.TabStop = true;
            this.rdoAM.Text = "AM";
            this.rdoAM.UseVisualStyleBackColor = true;
            // 
            // rdoPM
            // 
            this.rdoPM.AutoSize = true;
            this.rdoPM.Location = new System.Drawing.Point(627, 291);
            this.rdoPM.Name = "rdoPM";
            this.rdoPM.Size = new System.Drawing.Size(57, 24);
            this.rdoPM.TabIndex = 11;
            this.rdoPM.Text = "PM";
            this.rdoPM.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(575, 374);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(167, 118);
            this.btnSubmit.TabIndex = 12;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // frmTimeAndDelay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 504);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.rdoPM);
            this.Controls.Add(this.rdoAM);
            this.Controls.Add(this.txtQ3);
            this.Controls.Add(this.txtQ2);
            this.Controls.Add(this.txtQ1);
            this.Controls.Add(this.txtDM);
            this.Controls.Add(this.txtDH);
            this.Controls.Add(this.txtEM);
            this.Controls.Add(this.txtEH);
            this.Controls.Add(this.txtSM);
            this.Controls.Add(this.txtSH);
            this.Controls.Add(this.picUI);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "frmTimeAndDelay";
            this.Text = "Time Quiz Game";
            this.Load += new System.EventHandler(this.frmTimeAndDelay_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picUI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picUI;
        private System.Windows.Forms.TextBox txtSH;
        private System.Windows.Forms.TextBox txtSM;
        private System.Windows.Forms.TextBox txtEH;
        private System.Windows.Forms.TextBox txtEM;
        private System.Windows.Forms.TextBox txtDH;
        private System.Windows.Forms.TextBox txtDM;
        private System.Windows.Forms.TextBox txtQ1;
        private System.Windows.Forms.TextBox txtQ2;
        private System.Windows.Forms.TextBox txtQ3;
        private System.Windows.Forms.RadioButton rdoAM;
        private System.Windows.Forms.RadioButton rdoPM;
        private System.Windows.Forms.Button btnSubmit;
    }
}

