visual studio 2019 နဲ႔ အထက္ဆိုရင္ mysql-connector-net-XXX.msi ကို install လုပ္သံုးပါ
က်န္တဲ႔ visual studio version အေဟာင္းေတြဆို MySql.Data.DLL ကို ယူသံုးပါ။ သံုးနည္း အေသးစိတ္ကုိ PDF မွာ ၾကည္႔ပါ။