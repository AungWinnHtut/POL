#include<stdio.h>

int main()
{
	float A, R;
	R = 34.5;
	A = 3.1415 * R * R;
	printf("Area = %f", A);
	return 0;
}